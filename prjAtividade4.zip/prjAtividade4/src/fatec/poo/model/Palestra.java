/**
 * @author Maria Simões
 */

package fatec.poo.model;

public class Palestra {
    
    private String data, tema;
    private double valor;
    private Palestrante palestrante; // Multiplicidade 1 -- Ponteiro: armazena um endereço da classe Palestrante
    private Participante[] participantes; // Multiplicidade 1..* -- Ponteiro matriz: armazena os endereços da classe Participantes
    private int qtdParticipantes; //indice da matriz
    
    public Palestra(String tema, double valor) {
        this.tema = tema;
        this.valor = valor;
        this.participantes = new Participante[5];
        this.qtdParticipantes = 0;
    }

    public void setData(String data) {
        this.data = data;
    }
    
    public String getData() {
        return data;
    }

    public String getTema() {
        return tema;
    }

    public double getValor() {
        return valor;
    }

    public Palestrante getPalestrante() {
        return palestrante;
    }

    public void setPalestrante(Palestrante palestrante) {
        this.palestrante = palestrante;
    }
    
    
    public void addParticipante(Participante p) {
        participantes[qtdParticipantes] = p;
        qtdParticipantes++;
     
    }

    public double calcValorFaturado() {
        double total = 0;
        
        for (int x = 0; x < qtdParticipantes; x++) {
            Participante p = participantes[x];
            double valorPago = valor;
            
            switch (p.getTipo()) {
                case 'E': // TEM QUE FAZER PRA MINUSCULO TBM E TRATAR ERROS, SE FOR OUTRA LETRA -- REFAZER COM IF
                    valorPago -= valor * 0.15;
                    break;
                    
                case 'I':
                    valorPago -= valor * 0.20;
                    break;
                    
                default:
                    break;
            }
            total += valorPago;
        }
        return total;
    }
    
}
