/**
 * @author Maria Simões
 */

package fatec.poo.model;

public class Palestrante extends Pessoa{
    
    private String empresa;
    private double taxaCobranca;
    private Palestra[] palestras; // Multiplicidade 1..* -- Ponteiro Matriz
    
    public Palestrante(String cpf, String nome, String empresa) {
        super(cpf, nome);
        this.empresa = empresa;
    }

    public void setTaxaCobranca(double taxaCobranca) {
        this.taxaCobranca = taxaCobranca / 100;
    }
    
    public double getTaxaCobranca() {
        return taxaCobranca;
    }
    
    public String getEmpresa() {
        return empresa;
    }

    public double calcTotalReceberPalestras() {
        
        return(calcValorFaturado() * taxaCobranca);
    }    
    
}
