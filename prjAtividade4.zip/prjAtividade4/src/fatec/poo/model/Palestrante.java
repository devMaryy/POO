/**
 * @author Maria Simões
 */

package fatec.poo.model;

public class Palestrante extends Pessoa{
    
    private String empresa;
    private double taxaCobranca;
    private Palestra[] palestras; // Multiplicidade 1..* -- Ponteiro Matriz
    private int qtdPalestras; //indice matriz
    
    public Palestrante(String cpf, String nome, String empresa) {
        super(cpf, nome);
        this.empresa = empresa;
        this.palestras = new Palestra[2];
        this.qtdPalestras = 0;
    }

    public void setTaxaCobranca(double taxaCobranca) {
        this.taxaCobranca = taxaCobranca;
    }
    
    public double getTaxaCobranca() {
        return taxaCobranca;
    }
    
    public String getEmpresa() {
        return empresa;
    }
    
    public void addPalestra(Palestra p) {
        palestras[qtdPalestras] = p;
        qtdPalestras++;
        
    }

    public double calcTotalReceberPalestras() {
        double total = 0;
        
        for (int x = 0; x < qtdPalestras; x++) {
            total += palestras[x].calcValorFaturado();
        }
        return(total * (taxaCobranca / 100));
    }    
    
}
