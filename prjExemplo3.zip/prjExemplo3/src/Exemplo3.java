/**
 * @author Maria Simões
 */

public class Exemplo3 {

    public static void main(String[] args) {
        
        int cont;
        
        System.out.println("\tTABUADA DO SETE\n");
        
        for (cont = 1; cont <= 10; cont++) {
            System.out.println("7 * " + cont + " = " + cont * 7);
        }     
    }
}
