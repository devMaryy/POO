/**
 * @author Maria Simões
 */

public class Exemplo4 {

    public static void main(String[] args) {
        
        int x = 1;
        
        System.out.println("\tTABUADA DO SETE\n");
        
        while (x <= 10) {
            System.out.println("7 * " + x + " = " + x * 7);
            x++;
        }
    }
}
