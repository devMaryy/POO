/**
 * @author Maria Simões
 */

package fatec.poo.model;

public class Departamento {
    
    private String sigla, nome;
    private int numFunc;

    public Departamento(String sigla, String nome) {
        this.sigla = sigla; // THIS diferencia atributo de parâmetro, verde é atributo e preto é parâmetro.
        this.nome = nome;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSigla() {
        return sigla;
    }

    public String getNome() {
        return nome;
    }
    
}
