
import java.util.Scanner;

/**
 * @author Maria
 */

public class Aplic {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        
        int id, opcao;
        double multa;
        String titulo = null;
        boolean sit = false;
        
        System.out.print("Digite a identificacao do livro: ");
        id = entrada.nextInt();
        System.out.print("Digite o nome do livro: ");
        titulo = entrada.next(titulo);
              
        Livro obj1 = new Livro(id, titulo);
        
        do{
            System.out.println("\n\n1 - Consultar livro");
            System.out.println("2 - Emprestar livro");
            System.out.println("3 - Devolver livro");
            System.out.println("4 - Sair");
            System.out.print("\nDigite a opção: ");
            opcao = entrada.nextInt(); 
            
            if (opcao == 1){
                System.out.println("\nIdentificação do livro: " + 
                                    obj1.getIdentificacao());
                System.out.println("Nome do livro: " + obj1.getTitulo());
                if (sit) {
                    System.out.println("Livro disponível");
                }
                else {
                    System.out.println("Livro emprestado");
                }
               
            }else
               if (opcao == 2){
                   if (sit) {
                       System.out.println("Operação de empréstimo realizada com sucesso!");
                   }
                   else {
                       System.out.println("O livro está emprestado");
                   } 
               }else
                  if (opcao == 3){
                    if (sit) {
                        System.out.println("O livro já está disponível");
                    } 
                  } 
        }while(opcao < 4);
    }
    
}
