/**
 * @author Maria
 */

public class Livro {
    
    private int identificacao;
    private double valMultaDiaria;
    private String titulo;
    private boolean situacao;
    
    public Livro(int id, String ti) {
        identificacao = id;
        titulo = ti;
    }
    
    public void setMultaDiaria(double a) {
        valMultaDiaria = a;
    }
    
    public int getIdentificacao() {
        return(identificacao);
    }
    
    public String getTitulo() {
        return(titulo);
    }
    
    public boolean getSituacao() {
        return(situacao);
    }
    
    public void emprestar() {
        situacao = true;
    }
    
    public double devolver(int dias) {
        situacao = false;
        return(valMultaDiaria * dias);
    }
}
