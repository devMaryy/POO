/**
 * @author Maria Simões
 */

import fatec.poo.model.PessoaFisica;
import fatec.poo.model.PessoaJuridica;
import java.text.DecimalFormat;
import java.util.Scanner;

public class Aplic {

    public static void main(String[] args) {
        
        String nom, cp;
        int inscricao, anoAt;
        double bs;
        
        Scanner entrada = new Scanner(System.in);
        
        DecimalFormat df = new DecimalFormat("#,##0.00");
        
        System.out.println("Digite o CPF: ");
        cp = entrada.next();
        System.out.println("Digite o nome: ");
        nom = entrada.next();
        System.out.println("Digite o ano de inscrição: ");
        inscricao = entrada.nextInt();
        System.out.println("Digite o ano atual: ");
        anoAt = entrada.nextInt();
        
        PessoaFisica PesFis = new PessoaFisica(cp, nom, inscricao);
        
        System.out.println("Digite o valor da base: ");
        bs = entrada.nextDouble();
        PesFis.setBase(bs);
        
        PessoaJuridica PesJur = new PessoaJuridica("2222", "Anne Myers", 2012);
        PesJur.setTaxaIncentivo(52);
        
        System.out.println("\nPessoa Física:");
        System.out.println("Nome: " + PesFis.getNome());
        System.out.println("CPF: " + PesFis.getCpf());
        System.out.println("Ano Inscrição: " + PesFis.getAnoInscricao());
        System.out.println("Valor do bônus: " + PesFis.calcBonus(anoAt));
        
        System.out.println("\nPessoa Jurídica:");
        System.out.println("Nome: " + PesJur.getNome());
        System.out.println("CGC: " + PesJur.getCgc());
        System.out.println("Ano Inscrição: " + PesJur.getAnoInscricao());
        System.out.println("Taxa de Incentivo: " + PesJur.getTaxaIncentivo());
        System.out.println("Valor do bônus: " + PesJur.calcBonus(2024));
    }
    
}
