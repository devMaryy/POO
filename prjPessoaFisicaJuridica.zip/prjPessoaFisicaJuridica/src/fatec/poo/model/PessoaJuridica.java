/**
 * @author Maria Simões
 */

package fatec.poo.model;

public class PessoaJuridica extends Pessoa{
    
    private String cgc;
    private double taxaIncentivo;
    
    public PessoaJuridica(String c, String n, int anoIns) {
        super(n, anoIns);
        cgc = c;
    }
    
    public double calcBonus(int anoAtual) {
        return((taxaIncentivo * getTotalCompras()) * (anoAtual - getAnoInscricao()));
    }
    
    public void setTaxaIncentivo(double ti) {
        taxaIncentivo = ti / 100;
    }
    
    public double getTaxaIncentivo() {
        return(taxaIncentivo);
    }
    
    public String getCgc() {
        return(cgc);
    }
}
